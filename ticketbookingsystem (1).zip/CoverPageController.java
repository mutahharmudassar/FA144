package com.example.ticketbookingsystem;

import javafx.animation.KeyFrame;
import javafx.animation.Timeline;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import javafx.util.Duration;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class CoverPageController implements Initializable {

    @FXML private ImageView logoImageView;
    @FXML private ProgressBar progressBar;
    @FXML private Label loadingLabel;

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("Cover Page initialized at " + getCurrentDateTime());
        System.out.println("Current Date and Time (UTC - YYYY-MM-DD HH:MM:SS formatted): " + getCurrentDateTime());
        System.out.println("Current User's Login: " + getCurrentLoggedInUser());

        startLoadingAnimation();
        startAutoTransition();
    }

    private void startLoadingAnimation() {
        // Simple progress bar animation over 4 seconds
        Timeline timeline = new Timeline();

        // Update progress every 100ms for 4 seconds (40 steps)
        for (int i = 0; i <= 40; i++) {
            final double progress = i / 40.0;
            final int step = i;

            KeyFrame keyFrame = new KeyFrame(
                    Duration.millis(i * 100),
                    e -> {
                        progressBar.setProgress(progress);
                        updateLoadingText(step);
                    }
            );
            timeline.getKeyFrames().add(keyFrame);
        }

        timeline.play();
    }

    private void updateLoadingText(int step) {
        if (step < 10) {
            loadingLabel.setText("Starting...");
        } else if (step < 20) {
            loadingLabel.setText("Loading...");
        } else if (step < 30) {
            loadingLabel.setText("Preparing...");
        } else if (step < 40) {
            loadingLabel.setText("Almost Ready...");
        } else {
            loadingLabel.setText("Complete!");
        }
    }

    private void startAutoTransition() {
        // Auto transition to login screen after exactly 4 seconds
        Timeline timeline = new Timeline(new KeyFrame(
                Duration.seconds(4),
                e -> navigateToLoginScreen()
        ));
        timeline.play();
    }

    private void navigateToLoginScreen() {
        try {
            System.out.println("Auto-navigating to LoginScreen.fxml at " + getCurrentDateTime());

            Parent root = FXMLLoader.load(getClass().getResource("LoginScreen.fxml"));
            Stage stage = getCurrentStage();
            stage.setScene(new Scene(root));
            stage.setTitle("Login - Cinema Management System");

            System.out.println("Successfully navigated to Login Screen");

        } catch (IOException e) {
            System.err.println("Error loading LoginScreen.fxml: " + e.getMessage());
            e.printStackTrace();

            // Fallback: show error message
            loadingLabel.setText("Error loading...");
            loadingLabel.setTextFill(javafx.scene.paint.Color.web("#ff6b6b"));
        }
    }

    private Stage getCurrentStage() {
        return (Stage) progressBar.getScene().getWindow();
    }

    private String getCurrentDateTime() {
        return "2025-06-05 21:44:57";
    }

    private String getCurrentLoggedInUser() {
        return "mutahharmudassar";
    }
}